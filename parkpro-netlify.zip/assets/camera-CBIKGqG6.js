import{c as n}from"./index-DaWwaIyv.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h=n("CameraOff",[["line",{x1:"2",x2:"22",y1:"2",y2:"22",key:"a6p6uj"}],["path",{d:"M7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16",key:"qmtpty"}],["path",{d:"M9.5 4h5L17 7h3a2 2 0 0 1 2 2v7.5",key:"1ufyfc"}],["path",{d:"M14.121 15.121A3 3 0 1 1 9.88 10.88",key:"11zox6"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=n("Camera",[["path",{d:"M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z",key:"1tc9qg"}],["circle",{cx:"12",cy:"13",r:"3",key:"1vg3eu"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=n("SwitchCamera",[["path",{d:"M11 19H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h5",key:"mtk2lu"}],["path",{d:"M13 5h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-5",key:"120jsl"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}],["path",{d:"m18 22-3-3 3-3",key:"kgdoj7"}],["path",{d:"m6 2 3 3-3 3",key:"1fnbkv"}]]);function s(){return typeof window>"u"?!1:window.isSecureContext||location.protocol==="https:"||location.hostname==="localhost"||location.hostname==="127.0.0.1"}async function l(e){if(!navigator.mediaDevices?.getUserMedia)throw new Error("Camera API unavailable");try{return await navigator.mediaDevices.getUserMedia({audio:!1,video:{facingMode:{ideal:e},width:{ideal:1280},height:{ideal:960},frameRate:{ideal:24,max:30}}})}catch(a){const t=a?.name;if(t==="OverconstrainedError"||t==="NotFoundError")return navigator.mediaDevices.getUserMedia({audio:!1,video:!0});throw a}}function g(e){e?.getTracks().forEach(a=>a.stop())}function p(e){return e?.getVideoTracks()[0]??null}function d(e){return e?!!e.getCapabilities?.()?.torch:!1}async function y(e,a){if(!e||!d(e))return!1;try{return await e.applyConstraints({advanced:[{torch:a}]}),!0}catch{return!1}}function v(e){if(!e.videoWidth||!e.videoHeight)return null;const t=Math.min(1,1280/Math.max(e.videoWidth,e.videoHeight)),o=Math.round(e.videoWidth*t),i=Math.round(e.videoHeight*t),r=document.createElement("canvas");r.width=o,r.height=i;const c=r.getContext("2d");return c?(c.drawImage(e,0,0,o,i),r.toDataURL("image/jpeg",.85)):null}function w(e){if(!s())return"insecure";const a=e?.name;return a==="NotAllowedError"||a==="SecurityError"||a==="PermissionDeniedError"?"denied":a==="NotFoundError"||a==="DevicesNotFoundError"?"notfound":"unknown"}export{h as C,f as S,p as a,y as b,w as c,m as d,v as e,l as g,s as i,g as s,d as t};
